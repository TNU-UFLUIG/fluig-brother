// Enviar ND via Portal
function intermediateconditional186() {
	return hAPI.getCardValue("envioNDConcluido") == "true";
}