// Enviar Evidências via Portal
function intermediateconditional180() {
	return hAPI.getCardValue("envioEvidenciasConcluido") == "true";
}