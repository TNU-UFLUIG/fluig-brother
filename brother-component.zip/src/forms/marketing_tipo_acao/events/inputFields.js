/*eslint-disable*/
/*jshint -W116 */
function inputFields(form) {

  const Params = getParams(form);

  const importado = value(form, 'importado');
  
}
